#include "main.h"

void BSP_Init(void)
{
 	Led_Configuration();
}


